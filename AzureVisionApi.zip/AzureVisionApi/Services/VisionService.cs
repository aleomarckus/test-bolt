using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System.Drawing;
using System.Net.Http.Headers;

namespace AzureVisionApi.Services
{
    public class VisionService
    {
        private const string subscriptionKey = "YOUR_AZURE_VISION_KEY";
        private const string endpoint = "YOUR_AZURE_VISION_ENDPOINT";

        public async Task<string> AnalyzeImageWithOCR(string imagePath)
        {
            var client = new ComputerVisionClient(new ApiKeyServiceClientCredentials(subscriptionKey))
            {
                Endpoint = endpoint
            };

            using var stream = File.OpenRead(imagePath);
            var ocrResult = await client.ReadInStreamAsync(stream);

            string operationLocation = ocrResult.OperationLocation;
            string operationId = operationLocation.Substring(operationLocation.Length - 36);

            ReadOperationResult results;
            do
            {
                results = await client.GetReadResultAsync(Guid.Parse(operationId));
                await Task.Delay(1000);
            } while (results.Status == OperationStatusCodes.Running || results.Status == OperationStatusCodes.NotStarted);

            var outputPath = Path.Combine("wwwroot", "output.jpg");
            var image = new Bitmap(imagePath);
            using var graphics = Graphics.FromImage(image);
            var pen = new Pen(Color.Red, 2);

            foreach (var result in results.AnalyzeResult.ReadResults)
            {
                foreach (var line in result.Lines)
                {
                    var points = line.BoundingBox;
                    if (points.Count == 8)
                    {
                        var rect = new Rectangle((int)points[0], (int)points[1],
                            (int)(points[2] - points[0]), (int)(points[5] - points[1]));
                        graphics.DrawRectangle(pen, rect);
                    }
                }
            }

            image.Save(outputPath);
            return outputPath;
        }
    }
}