using OfficeOpenXml;
using System.Drawing;

namespace AzureVisionNet5Api.Services
{
    public class ExcelService
    {
        public string InsertImageToExcel(string imagePath)
        {
            var excelPath = Path.Combine("wwwroot", "output.xlsx");

            using (var package = new ExcelPackage())
            {
                var ws = package.Workbook.Worksheets.Add("Image");
                var image = Image.FromFile(imagePath);

                var pic = ws.Drawings.AddPicture("ProcessedImage", image);
                pic.SetPosition(1, 0, 1, 0);
                package.SaveAs(new FileInfo(excelPath));
            }

            return excelPath;
        }
    }
}