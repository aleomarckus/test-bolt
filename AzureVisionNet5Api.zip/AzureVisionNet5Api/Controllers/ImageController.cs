using AzureVisionNet5Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace AzureVisionNet5Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ImageController : ControllerBase
    {
        private readonly VisionService _visionService;
        private readonly ExcelService _excelService;

        public ImageController(VisionService visionService, ExcelService excelService)
        {
            _visionService = visionService;
            _excelService = excelService;
        }

        [HttpPost("analyze")]
        public async Task<IActionResult> AnalyzeImage([FromForm] IFormFile imageFile)
        {
            if (imageFile == null || imageFile.Length == 0)
                return BadRequest("No image uploaded.");

            var filePath = Path.Combine("wwwroot", "input.jpg");
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await imageFile.CopyToAsync(stream);
            }

            var outputImagePath = await _visionService.AnalyzeImageWithOCR(filePath);
            var excelPath = _excelService.InsertImageToExcel(outputImagePath);

            var bytes = System.IO.File.ReadAllBytes(excelPath);
            return File(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "result.xlsx");
        }
    }
}