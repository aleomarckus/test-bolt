const express = require('express');
const fs = require('fs');
const path = require('path');
const { sendDiscordImage } = require('./sendDiscordImage');

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

app.post('/upload-base64', async (req, res) => {
    const { base64, fileName = 'output.jpg', message = '📷 Uploaded image:' } = req.body;

    if (!base64 || !base64.startsWith('data:image')) {
        return res.status(400).json({ error: 'Invalid or missing base64 image data' });
    }

    const matches = base64.match(/^data:(image\/\w+);base64,(.+)$/);
    if (!matches) {
        return res.status(400).json({ error: 'Malformed base64 string' });
    }

    const mimeType = matches[1];
    const imageBuffer = Buffer.from(matches[2], 'base64');
    const ext = mimeType.split('/')[1];
    const finalFileName = fileName.endsWith(`.${ext}`) ? fileName : `${fileName}.${ext}`;
    const outputPath = path.join(__dirname, 'uploads', finalFileName);

    try {
        fs.mkdirSync(path.dirname(outputPath), { recursive: true });
        fs.writeFileSync(outputPath, imageBuffer);

        console.log('✅ Image saved:', outputPath);

        const discordResult = await sendDiscordImage(outputPath, message);
        if (!discordResult) {
            return res.status(500).json({ error: 'Failed to send image to Discord' });
        }

        res.json({ message: '✅ Image saved and sent to Discord', file: outputPath });
    } catch (err) {
        console.error('❌ Save error:', err.message);
        res.status(500).json({ error: 'Failed to save image' });
    }
});

app.listen(PORT, () => {
    console.log(`🚀 API running at http://localhost:${PORT}`);
});
