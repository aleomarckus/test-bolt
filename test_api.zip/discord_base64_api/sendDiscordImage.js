const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');

const BOT_TOKEN = 'MTM3Njk2MjQ2MTQ3NTAxNjc2Ng.G44bb4.4CGHcLT3aOyJZtA4blcnF3obEMwaGHia2n7Yp4';
const CHANNEL_ID = '1304472338875547661';

async function sendDiscordImage(filePath, messageText = '📷 Here is your image') {
    try {
        const form = new FormData();
        form.append('file', fs.createReadStream(filePath));
        form.append('payload_json', JSON.stringify({ content: messageText }));

        const res = await axios.post(
            `https://discord.com/api/v10/channels/${CHANNEL_ID}/messages`,
            form,
            {
                headers: {
                    Authorization: `Bot ${BOT_TOKEN}`,
                    ...form.getHeaders()
                }
            }
        );

        return true;
    } catch (err) {
        return false;
    }
}

module.exports = { sendDiscordImage };
