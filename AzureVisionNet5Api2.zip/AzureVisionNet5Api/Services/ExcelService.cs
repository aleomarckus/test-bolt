
using OfficeOpenXml;
using OfficeOpenXml.Drawing;
using System.IO;

namespace AzureVisionNet5Api.Services
{
    public class ExcelService
    {
        public string InsertImageToExcel(string imagePath)
        {
            var excelPath = Path.Combine("wwwroot", "output.xlsx");

            using (var package = new ExcelPackage())
            {
                var ws = package.Workbook.Worksheets.Add("Image");

                var imageBytes = File.ReadAllBytes(imagePath);
                using var stream = new MemoryStream(imageBytes);
                var pic = ws.Drawings.AddPicture("ProcessedImage", stream, ePictureType.Jpeg);
                pic.SetPosition(1, 0, 1, 0);

                package.SaveAs(new FileInfo(excelPath));
            }

            return excelPath;
        }
    }
}
