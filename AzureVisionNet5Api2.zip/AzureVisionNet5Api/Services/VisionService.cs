
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading.Tasks;

namespace AzureVisionNet5Api.Services
{
    public class VisionService
    {
        private readonly string endpoint = "YOUR_AZURE_ENDPOINT";
        private readonly string key = "YOUR_AZURE_KEY";

        public async Task<string> ProcessImageAsync(string imagePath)
        {
            var client = new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
            {
                Endpoint = endpoint
            };

            using var imageStream = File.OpenRead(imagePath);
            var result = await client.ReadInStreamAsync(imageStream);
            string operationLocation = result.OperationLocation;
            string operationId = operationLocation.Substring(operationLocation.Length - 36);

            ReadOperationResult results;
            do
            {
                results = await client.GetReadResultAsync(Guid.Parse(operationId));
                await Task.Delay(1000);
            } while (results.Status == OperationStatusCodes.Running || results.Status == OperationStatusCodes.NotStarted);

            var lines = new List<ReadResult>();
            foreach (var page in results.AnalyzeResult.ReadResults)
            {
                lines.Add(page);
            }

            var image = Image.FromFile(imagePath);
            using var g = Graphics.FromImage(image);
            var pen = new Pen(Color.Red, 3);

            foreach (var page in lines)
            {
                foreach (var line in page.Lines)
                {
                    var rect = new Rectangle((int)line.BoundingBox[0], (int)line.BoundingBox[1],
                        (int)(line.BoundingBox[2] - line.BoundingBox[0]),
                        (int)(line.BoundingBox[5] - line.BoundingBox[1]));
                    g.DrawRectangle(pen, rect);
                }
            }

            var processedPath = Path.Combine("wwwroot", "processed.jpg");
            image.Save(processedPath, ImageFormat.Jpeg);
            return processedPath;
        }
    }
}
