
using AzureVisionNet5Api.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Threading.Tasks;

namespace AzureVisionNet5Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class VisionController : ControllerBase
    {
        private readonly VisionService _visionService;
        private readonly ExcelService _excelService;

        public VisionController(VisionService visionService, ExcelService excelService)
        {
            _visionService = visionService;
            _excelService = excelService;
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadImage(IFormFile file)
        {
            var filePath = Path.Combine("wwwroot", file.FileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var processedImagePath = await _visionService.ProcessImageAsync(filePath);
            var excelPath = _excelService.InsertImageToExcel(processedImagePath);

            return Ok(new { image = processedImagePath, excel = excelPath });
        }
    }
}
